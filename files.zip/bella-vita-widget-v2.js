/**
 * Bella Vita Restaurant AI Widget v2
 * ─────────────────────────────────────────────────────────
 * Volá tvůj Cloudflare Worker (bezpečný proxy) místo Claude API přímo.
 *
 * Embed na web restaurace:
 *   <script>
 *     window.BellaVitaConfig = {
 *       proxyUrl: 'https://tvuj-worker.tvojejmeno.workers.dev/chat',
 *       restaurantName: 'Název restaurace',
 *       primaryColor: '#C9913A',
 *       position: 'bottom-right'
 *     };
 *   </script>
 *   <script src="bella-vita-widget.js"></script>
 */

(function () {
  'use strict';

  const scriptEl = document.currentScript || document.querySelector('script[data-restaurant]');

  const CFG = Object.assign({
    proxyUrl:       'https://ТВОЙ-WORKER.workers.dev/chat', // ← sem dáš URL svého Workeru
    primaryColor:   '#C9913A',
    primaryLight:   '#E8BE72',
    position:       'bottom-right',
    restaurantName: 'Bella Vita',
    agentName:      'Sofia',
  }, window.BellaVitaConfig || {}, scriptEl ? {
    proxyUrl:       scriptEl.dataset.proxyUrl       || window.BellaVitaConfig?.proxyUrl,
    primaryColor:   scriptEl.dataset.primaryColor   || '#C9913A',
    position:       scriptEl.dataset.position       || 'bottom-right',
    restaurantName: scriptEl.dataset.restaurantName || 'Bella Vita',
  } : {});

  // ─── STORAGE KEYS ───────────────────────────────────────
  const slug = CFG.restaurantName.replace(/\s/g, '_').toLowerCase();
  const STORE_KEY = `bv_memory_${slug}`;
  const HIST_KEY  = `bv_history_${slug}`;

  // ─── MEMORY ─────────────────────────────────────────────
  const Memory = {
    load()        { try { return JSON.parse(localStorage.getItem(STORE_KEY) || '{}'); } catch { return {}; } },
    save(d)       { try { localStorage.setItem(STORE_KEY, JSON.stringify(d)); } catch {} },
    get(k)        { return this.load()[k]; },
    set(k, v)     { const m = this.load(); m[k] = v; m._updated = Date.now(); this.save(m); },
    update(u)     { const m = this.load(); Object.assign(m, u, { _updated: Date.now() }); this.save(m); },
    getAll()      { return this.load(); },
    buildContext() {
      const m = this.load();
      if (!m._updated) return '';
      const p = [];
      if (m.name)              p.push(`Zákazník: ${m.name}.`);
      if (m.phone)             p.push(`Tel: ${m.phone}.`);
      if (m.visits)            p.push(`Počet návštěv: ${m.visits}.`);
      if (m.lastVisit)         p.push(`Poslední návštěva: ${m.lastVisit}.`);
      if (m.preferences?.length)   p.push(`Preference: ${m.preferences.join(', ')}.`);
      if (m.allergies?.length)     p.push(`Alergie: ${m.allergies.join(', ')}.`);
      if (m.favoriteDishes?.length) p.push(`Oblíbená jídla: ${m.favoriteDishes.join(', ')}.`);
      if (m.lastReservation)   p.push(`Poslední rezervace: ${m.lastReservation}.`);
      if (m.notes)             p.push(`Poznámky: ${m.notes}.`);
      return p.length ? `\n\nPAMĚŤ ZÁKAZNÍKA:\n${p.join(' ')}` : '';
    }
  };

  const History = {
    load()        { try { return JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); } catch { return []; } },
    save(a)       { try { localStorage.setItem(HIST_KEY, JSON.stringify(a.slice(-20))); } catch {} },
    add(role, content) { const h = this.load(); h.push({ role, content }); this.save(h); },
    get()         { return this.load(); },
    clear()       { localStorage.removeItem(HIST_KEY); }
  };

  // ─── AGENTS ─────────────────────────────────────────────
  function buildAgents() {
    const mem = Memory.buildContext();
    const name = Memory.get('name');
    const greet = name ? `Zákazník ${name} se vrátil — pozdrav ho jménem.` : '';

    return {
      orchestrator: {
        id: 'orchestrator', name: 'Orchestrátor', emoji: '🧠', color: CFG.primaryColor,
        system: `Jsi orchestrátor AI systému restaurace ${CFG.restaurantName}.
Rozhodni který agent odpoví. Vyber JEDEN: reservation, menu, navigation, support
- reservation: rezervace, dostupnost, storno
- menu: jídla, ceny, alergeny, diety, doporučení
- navigation: doprava, parkování, otevírací doba, web
- support: stížnosti, speciální přání, reklamace
Odpověz POUZE JSON: {"agent":"název","reason":"důvod max 6 slov","context":"co potřebuje"}${mem}`
      },
      reservation: {
        id: 'reservation', name: 'Rezervace', emoji: '📅', color: '#5B9BD5',
        system: `Jsi rezervační agent restaurace ${CFG.restaurantName}. ${greet}
Kapacita 60 míst | Po–Pá 11–23h, So–Ne 12–24h | Rezervace min. 2h předem
Skupiny 8+: záloha 200 Kč/os | Storno zdarma do 24h | Tel: +420 222 333 444
Pokud chce rezervovat → přidej [SHOW_FORM]. Pokud zmíní jméno/alergii → [REMEMBER:klíč=hodnota]
Odpovídej česky.${mem}`
      },
      menu: {
        id: 'menu', name: 'Menu', emoji: '🍝', color: '#7DC17A',
        system: `Jsi menu agent restaurace ${CFG.restaurantName}. ${greet}
MENU: Bruschetta 159Kč(V) | Caprese 189Kč(V) | Carpaccio 229Kč | Minestrone 129Kč(V)
Carbonara 279Kč | Ragù 299Kč | Arrabbiata 249Kč(V) | Risotto Funghi 319Kč(V,GF)
Margherita 249Kč(V) | Diavola 289Kč | Q.Formaggi 309Kč(V) | Prosciutto&Rucola 329Kč
Osso Buco 499Kč | Saltimbocca 469Kč | Branzino 529Kč(GF)
Tiramisù 149Kč | Panna Cotta 139Kč(V,GF) | Vína od 159Kč | Aperol 159Kč
(V=veg, GF=bezlep nebo +30Kč) Pokud zmíní alergii → [REMEMBER:allergies=hodnota]
Odpovídej česky, doporuč kombinace.${mem}`
      },
      navigation: {
        id: 'navigation', name: 'Navigace', emoji: '🗺️', color: '#C47AB8',
        system: `Jsi navigační agent restaurace ${CFG.restaurantName}. ${greet}
Náměstí Míru 12, Praha 2 | Metro A – Náměstí Míru (3 min) | Tram 4,10,16,22
Parkování: Vinohrady Plaza | Po–Pá 11–23h, So–Ne 12–24h
Web: /menu /rezervace /galerie /o-nas /kontakt
Odpovídej česky.${mem}`
      },
      support: {
        id: 'support', name: 'Podpora', emoji: '💬', color: '#E07A5F',
        system: `Jsi zákaznický agent restaurace ${CFG.restaurantName}. ${greet}
Řeš stížnosti empaticky. Nabídni: sleva 15%, náhradní chod, aperitiv zdarma.
Eskalace: manager@bellavita.cz / +420 222 333 445
Pokud sdělí jméno → [REMEMBER:name=hodnota]. Odpovídej česky.${mem}`
      }
    };
  }

  // ─── API CALL — přes tvůj Worker ────────────────────────
  async function callProxy(system, messages) {
    const r = await fetch(CFG.proxyUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ system, messages })
    });
    if (!r.ok) throw new Error(`Proxy ${r.status}`);
    const d = await r.json();
    if (d.error) throw new Error(d.error);
    return d.content.map(b => b.text || '').join('');
  }

  // ─── MEMORY TAG PROCESSING ───────────────────────────────
  function processMemoryTags(text) {
    const tags = [...text.matchAll(/\[REMEMBER:([^\]]+)\]/g)];
    tags.forEach(m => {
      const [key, ...rest] = m[1].split('=');
      const val = rest.join('=').trim();
      const k = key.trim();
      if (['allergies','preferences','favoriteDishes'].includes(k)) {
        const ex = Memory.get(k) || [];
        if (!ex.includes(val)) Memory.set(k, [...ex, val]);
      } else {
        Memory.set(k, val);
      }
    });
    if (tags.length) Memory.set('visits', (Memory.get('visits') || 0) + 1);
    return text.replace(/\[REMEMBER:[^\]]+\]/g, '').trim();
  }

  // ─── CSS ─────────────────────────────────────────────────
  function injectStyles() {
    if (document.getElementById('bv-styles')) return;
    const s = document.createElement('style');
    s.id = 'bv-styles';
    s.textContent = `
      #bv-root *{box-sizing:border-box;margin:0;padding:0;font-family:system-ui,'Segoe UI',sans-serif}
      #bv-fab{
        position:fixed;${CFG.position==='bottom-left'?'left:24px':'right:24px'};bottom:24px;
        width:60px;height:60px;border-radius:50%;
        background:linear-gradient(135deg,${CFG.primaryColor},${CFG.primaryLight});
        border:none;cursor:pointer;font-size:24px;z-index:2147483647;
        box-shadow:0 4px 20px rgba(0,0,0,0.25);
        display:flex;align-items:center;justify-content:center;
        transition:transform .2s;animation:bvpulse 3s infinite;
      }
      #bv-fab:hover{transform:scale(1.08)}
      @keyframes bvpulse{0%,100%{box-shadow:0 4px 20px rgba(0,0,0,.25),0 0 0 0 ${CFG.primaryColor}55}50%{box-shadow:0 4px 20px rgba(0,0,0,.25),0 0 0 10px ${CFG.primaryColor}00}}
      .bv-notif{position:absolute;top:-2px;right:-2px;width:18px;height:18px;border-radius:50%;background:#E05757;color:white;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;border:2px solid white}
      #bv-panel{
        position:fixed;${CFG.position==='bottom-left'?'left:24px':'right:24px'};bottom:96px;
        width:370px;height:555px;background:#FFFDF8;border-radius:20px;
        box-shadow:0 24px 80px rgba(0,0,0,0.18),0 0 0 1px rgba(0,0,0,0.07);
        display:flex;flex-direction:column;overflow:hidden;z-index:2147483646;
        transform:scale(0.9) translateY(16px);opacity:0;pointer-events:none;
        transition:transform .3s cubic-bezier(.34,1.56,.64,1),opacity .2s;
        transform-origin:${CFG.position==='bottom-left'?'bottom left':'bottom right'};
      }
      #bv-panel.open{transform:scale(1) translateY(0);opacity:1;pointer-events:all}
      #bv-hdr{background:#1A1208;padding:13px 16px;display:flex;align-items:center;gap:11px;flex-shrink:0;position:relative;overflow:hidden}
      #bv-hdr::after{content:'';position:absolute;bottom:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,${CFG.primaryColor},transparent)}
      .bv-hav{width:38px;height:38px;border-radius:9px;background:linear-gradient(135deg,${CFG.primaryColor},${CFG.primaryLight});display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0;position:relative}
      .bv-hav::after{content:'';position:absolute;bottom:-1px;right:-1px;width:10px;height:10px;border-radius:50%;background:#4ADE80;border:2px solid #1A1208}
      .bv-hname{color:#F7F3EC;font-size:14px;font-weight:600}
      .bv-hsub{font-size:11px;color:${CFG.primaryColor};opacity:.85}
      .bv-hmem{margin-left:auto;font-size:10px;letter-spacing:1px;color:${CFG.primaryColor};border:1px solid ${CFG.primaryColor}44;background:${CFG.primaryColor}15;padding:3px 8px;border-radius:20px;cursor:pointer;white-space:nowrap}
      .bv-hclose{background:rgba(255,255,255,0.08);border:none;width:26px;height:26px;border-radius:6px;color:#F7F3EC;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;margin-left:6px}
      #bv-toast{position:absolute;top:64px;${CFG.position==='bottom-left'?'left:0':'right:0'};width:100%;background:#1A1208;border-top:1px solid ${CFG.primaryColor}33;padding:10px 14px;font-size:11.5px;color:#F7F3EC99;line-height:1.5;display:none;z-index:5}
      #bv-toast b{color:${CFG.primaryColor}}
      .bv-clearmem{display:inline-block;margin-top:5px;color:#E05757;font-size:11px;cursor:pointer;text-decoration:underline}
      #bv-pill{padding:5px 14px;background:#F7F3EC;border-bottom:1px solid rgba(0,0,0,0.06);font-size:11px;color:#6B5E4A;display:flex;align-items:center;gap:6px;flex-shrink:0;min-height:30px}
      .bv-pd{width:6px;height:6px;border-radius:50%;background:#ccc;flex-shrink:0;transition:background .3s}
      .bv-pd.thinking{animation:bvthink .8s infinite}
      @keyframes bvthink{0%,100%{opacity:1}50%{opacity:.25}}
      #bv-msgs{flex:1;overflow-y:auto;padding:14px 12px;display:flex;flex-direction:column;gap:10px;scroll-behavior:smooth}
      #bv-msgs::-webkit-scrollbar{width:3px}
      #bv-msgs::-webkit-scrollbar-thumb{background:${CFG.primaryColor}33;border-radius:3px}
      .bv-row{display:flex;gap:7px;align-items:flex-end;max-width:88%;animation:bvfi .25s ease}
      .bv-row.ai{margin-right:auto}.bv-row.user{flex-direction:row-reverse;margin-left:auto}
      @keyframes bvfi{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
      .bv-av{width:26px;height:26px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:13px;flex-shrink:0;border:1px solid rgba(0,0,0,0.08)}
      .bv-bbl{padding:9px 12px;border-radius:13px;font-size:13.5px;line-height:1.55}
      .bv-row.ai .bv-bbl{background:white;color:#1A1208;border:1px solid rgba(0,0,0,0.08);border-bottom-left-radius:4px}
      .bv-row.user .bv-bbl{background:${CFG.primaryColor};color:white;font-weight:500;border-bottom-right-radius:4px}
      .bv-bbl b{color:${CFG.primaryColor}}.bv-row.user .bv-bbl b{color:white}
      .bv-bbl ul{padding-left:14px;margin-top:4px}.bv-bbl li{margin-bottom:2px}
      .bv-membadge{display:inline-flex;align-items:center;gap:4px;font-size:10px;color:${CFG.primaryColor};background:${CFG.primaryColor}12;border:1px solid ${CFG.primaryColor}25;padding:2px 8px;border-radius:10px;margin-top:5px}
      .bv-qrs{display:flex;flex-wrap:wrap;gap:5px;margin-top:7px}
      .bv-qr{background:transparent;border:1px solid ${CFG.primaryColor}55;color:${CFG.primaryColor};font-size:11px;padding:4px 10px;border-radius:20px;cursor:pointer;transition:all .15s;font-family:inherit}
      .bv-qr:hover{background:${CFG.primaryColor};color:white;border-color:${CFG.primaryColor}}
      .bv-typing{display:flex;gap:4px;padding:9px 11px}
      .bv-typing span{width:5px;height:5px;border-radius:50%;background:${CFG.primaryColor};opacity:.4;animation:bvdot 1.2s infinite}
      .bv-typing span:nth-child(2){animation-delay:.2s}.bv-typing span:nth-child(3){animation-delay:.4s}
      @keyframes bvdot{0%,60%,100%{opacity:.4;transform:scale(1)}30%{opacity:1;transform:scale(1.25)}}
      .bv-rf{background:#FDF8F0;border:1px solid ${CFG.primaryColor}33;border-radius:10px;padding:11px;margin-top:7px}
      .bv-rf-title{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:${CFG.primaryColor};margin-bottom:9px}
      .bv-rf-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px}
      .bv-rff label{display:block;font-size:9.5px;color:#6B5E4A;margin-bottom:2px}
      .bv-rff input,.bv-rff select{width:100%;background:white;border:1px solid rgba(0,0,0,0.12);color:#1A1208;font-family:inherit;font-size:12px;padding:6px 8px;border-radius:6px;outline:none;transition:border-color .2s}
      .bv-rff input:focus,.bv-rff select:focus{border-color:${CFG.primaryColor}}
      .bv-rfsub{margin-top:9px;width:100%;background:linear-gradient(135deg,${CFG.primaryColor},${CFG.primaryLight});color:#1A1208;border:none;padding:8px;border-radius:7px;font-family:inherit;font-weight:600;font-size:12px;cursor:pointer}
      .bv-rfsub:hover{opacity:.9}
      .bv-conf{display:inline-flex;align-items:center;gap:5px;background:#4ADE8015;border:1px solid #4ADE8033;color:#16A34A;font-size:11px;padding:4px 10px;border-radius:20px;margin-top:5px}
      #bv-ibar{padding:11px 12px;background:white;border-top:1px solid rgba(0,0,0,0.07);display:flex;gap:8px;align-items:center;flex-shrink:0}
      #bv-iwrap{flex:1;background:#F7F3EC;border:1px solid rgba(0,0,0,0.1);border-radius:10px;display:flex;align-items:center;padding:0 11px;transition:border-color .2s}
      #bv-iwrap:focus-within{border-color:${CFG.primaryColor}88}
      #bv-inp{flex:1;border:none;background:transparent;color:#1A1208;font-family:inherit;font-size:13px;padding:10px 0;outline:none}
      #bv-inp::placeholder{color:#9E8E7A}
      #bv-send{width:38px;height:38px;flex-shrink:0;background:linear-gradient(135deg,${CFG.primaryColor},${CFG.primaryLight});border:none;border-radius:9px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:opacity .2s}
      #bv-send:hover{opacity:.88}
      #bv-send svg{width:15px;height:15px;fill:#1A1208}
      #bv-foot{text-align:center;padding:4px;font-size:9.5px;color:#9E8E7A;background:white;flex-shrink:0}
      @media(max-width:420px){#bv-panel{width:calc(100vw - 24px);right:12px;left:12px}}
    `;
    document.head.appendChild(s);
  }

  // ─── DOM ─────────────────────────────────────────────────
  function buildDOM() {
    const root = document.createElement('div');
    root.id = 'bv-root';
    root.innerHTML = `
      <button id="bv-fab" aria-label="Chat">🍽️</button>
      <div id="bv-panel">
        <div id="bv-hdr">
          <div class="bv-hav">🍽️</div>
          <div>
            <div class="bv-hname">${CFG.agentName} · ${CFG.restaurantName}</div>
            <div class="bv-hsub">AI asistentka · Online</div>
          </div>
          <div class="bv-hmem" id="bv-membtn">💾 Paměť</div>
          <button class="bv-hclose" id="bv-close">✕</button>
        </div>
        <div id="bv-toast">
          <div id="bv-toast-content"></div>
          <span class="bv-clearmem" id="bv-clearmem">Smazat paměť a historii</span>
        </div>
        <div id="bv-pill">
          <div class="bv-pd" id="bv-pd"></div>
          <span id="bv-pill-text">Čekám na váš dotaz…</span>
        </div>
        <div id="bv-msgs"></div>
        <div id="bv-ibar">
          <div id="bv-iwrap">
            <input id="bv-inp" type="text" placeholder="Napište zprávu…" autocomplete="off"/>
          </div>
          <button id="bv-send">
            <svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
          </button>
        </div>
        <div id="bv-foot">Powered by Claude AI</div>
      </div>`;
    document.body.appendChild(root);
  }

  // ─── WIDGET STATE ────────────────────────────────────────
  let isOpen = false;
  let busy   = false;

  function toggle() {
    isOpen = !isOpen;
    document.getElementById('bv-panel').classList.toggle('open', isOpen);
    document.getElementById('bv-fab').textContent = isOpen ? '✕' : '🍽️';
    document.getElementById('bv-fab').querySelector('.bv-notif')?.remove();
    if (isOpen) document.getElementById('bv-inp').focus();
  }

  function setPill(text, color, thinking) {
    document.getElementById('bv-pill-text').textContent = text;
    const d = document.getElementById('bv-pd');
    d.style.background = color;
    d.classList.toggle('thinking', thinking);
  }

  function addMsg(role, html, agentId, qrs = []) {
    const agents = buildAgents();
    const agent  = agentId ? agents[agentId] : null;
    const msgs   = document.getElementById('bv-msgs');
    const row    = document.createElement('div');
    row.className = `bv-row ${role}`;

    const memBadge = (role === 'ai' && Memory.get('name') && agentId !== 'orchestrator')
      ? `<br><span class="bv-membadge">💾 Pamatuji si vás</span>` : '';
    const qrHtml  = qrs.length
      ? `<div class="bv-qrs">${qrs.map(q => `<button class="bv-qr" onclick="window._bvS('${q.replace(/'/g,"\\'")}')">${q}</button>`).join('')}</div>`
      : '';

    if (role === 'ai' && agent) {
      row.innerHTML = `
        <div class="bv-av" style="background:${agent.color}18;border-color:${agent.color}33">${agent.emoji}</div>
        <div class="bv-bbl">${html}${memBadge}${qrHtml}</div>`;
    } else {
      row.innerHTML = `<div class="bv-bbl">${html}</div>`;
    }
    msgs.appendChild(row);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTyping(agentId) {
    const agents = buildAgents();
    const a = agents[agentId];
    const msgs = document.getElementById('bv-msgs');
    const row  = document.createElement('div');
    row.className = 'bv-row ai'; row.id = 'bv-typing';
    row.innerHTML = `
      <div class="bv-av" style="background:${a?.color}18;border-color:${a?.color}33">${a?.emoji||'🤖'}</div>
      <div class="bv-bbl" style="background:white;border:1px solid rgba(0,0,0,0.08)">
        <div class="bv-typing"><span></span><span></span><span></span></div>
      </div>`;
    msgs.appendChild(row);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function hideTyping() { document.getElementById('bv-typing')?.remove(); }

  function showResForm(agentId) {
    const agents = buildAgents();
    const a = agents[agentId];
    const msgs = document.getElementById('bv-msgs');
    const today = new Date().toISOString().split('T')[0];
    const row = document.createElement('div');
    row.className = 'bv-row ai';
    row.innerHTML = `
      <div class="bv-av" style="background:${a.color}18;border-color:${a.color}33">${a.emoji}</div>
      <div class="bv-bbl">Skvěle, vyplňte prosím:
        <div class="bv-rf">
          <div class="bv-rf-title">✦ Rezervace · ${CFG.restaurantName}</div>
          <div class="bv-rf-grid">
            <div class="bv-rff"><label>Jméno</label><input id="bvrf-name" value="${Memory.get('name')||''}" placeholder="Jan Novák"></div>
            <div class="bv-rff"><label>Telefon</label><input id="bvrf-phone" value="${Memory.get('phone')||''}" placeholder="+420 ..."></div>
            <div class="bv-rff"><label>Datum</label><input id="bvrf-date" type="date" min="${today}"></div>
            <div class="bv-rff"><label>Čas</label>
              <select id="bvrf-time"><option value="">-- čas --</option>
                <option>12:00</option><option>12:30</option><option>13:00</option>
                <option>18:00</option><option>18:30</option><option>19:00</option>
                <option>19:30</option><option>20:00</option><option>20:30</option><option>21:00</option>
              </select>
            </div>
            <div class="bv-rff"><label>Osob</label>
              <select id="bvrf-guests">
                <option>1</option><option selected>2</option><option>3</option><option>4</option>
                <option>5</option><option>6</option><option>7</option><option>8+</option>
              </select>
            </div>
            <div class="bv-rff"><label>Přání</label><input id="bvrf-note" placeholder="narozeniny, alergie…"></div>
          </div>
          <button class="bv-rfsub" onclick="window._bvRes()">Potvrdit →</button>
        </div>
      </div>`;
    msgs.appendChild(row);
    msgs.scrollTop = msgs.scrollHeight;
  }

  window._bvRes = function () {
    const name  = document.getElementById('bvrf-name')?.value?.trim();
    const phone = document.getElementById('bvrf-phone')?.value?.trim();
    const date  = document.getElementById('bvrf-date')?.value;
    const time  = document.getElementById('bvrf-time')?.value;
    const guests= document.getElementById('bvrf-guests')?.value;
    const note  = document.getElementById('bvrf-note')?.value;
    if (!name || !phone || !date || !time) { alert('Vyplňte jméno, telefon, datum a čas.'); return; }
    const fmt = new Date(date).toLocaleDateString('cs-CZ', { day:'numeric', month:'long', year:'numeric' });
    Memory.update({ name, phone, lastReservation: `${fmt} ${time}, ${guests} os.`, lastVisit: new Date().toLocaleDateString('cs-CZ') });
    Memory.set('visits', (Memory.get('visits') || 0) + 1);
    if (note) Memory.set('notes', note);
    History.add('assistant', `Rezervace: ${name}, ${fmt} ${time}, ${guests} os.`);
    addMsg('ai', `<b>✓ Rezervace potvrzena</b><br>Jméno: <b>${name}</b><br>Termín: <b>${fmt} v ${time}</b><br>Počet: <b>${guests} os.</b>${note?`<br>Přání: <b>${note}</b>`:''}<br><span class="bv-conf">✓ Potvrzení odesláno</span>`, 'reservation', ['Zobrazit menu', 'Doprava k nám']);
  };

  function fmt(raw) {
    return raw
      .replace(/\*\*(.*?)\*\*/g, '<b>$1</b>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^[-•] (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>[\s\S]*?<\/li>)/g, '<ul>$1</ul>')
      .replace(/\n\n/g, '<br><br>').replace(/\n/g, '<br>');
  }

  function getQRs(agentId) {
    return {
      reservation: ['Zobrazit menu','Doprava k nám','Storno rezervace'],
      menu:        ['Zarezervovat stůl','Máte bezlepkové?','Doporučte víno'],
      navigation:  ['Zarezervovat stůl','Prohlédnout menu','Otevírací doba'],
      support:     ['Zarezervovat znovu','Zobrazit menu','Kontaktovat manažera'],
    }[agentId] || ['Zarezervovat stůl','Prohlédnout menu'];
  }

  // ─── MAIN FLOW ───────────────────────────────────────────
  async function process(text) {
    if (busy) return;
    busy = true;
    addMsg('user', text);
    History.add('user', text);

    const agents = buildAgents();
    try {
      // 1. Orchestrator
      setPill('Analyzuji dotaz…', CFG.primaryColor, true);
      const orchRaw = await callProxy(
        agents.orchestrator.system,
        [{ role: 'user', content: text }]
      );
      let decision;
      try { decision = JSON.parse(orchRaw.replace(/```json|```/g,'').trim()); }
      catch { decision = { agent: 'support', reason: 'fallback', context: text }; }

      const agentId = (decision.agent in agents && decision.agent !== 'orchestrator')
        ? decision.agent : 'support';
      const agent   = agents[agentId];

      // 2. Specialist
      setPill(`${agent.emoji} ${agent.name} — ${decision.reason}`, agent.color, true);
      showTyping(agentId);

      const raw = await callProxy(
        agent.system,
        [...History.get().slice(-12), { role: 'user', content: text }]
      );
      hideTyping();

      let cleaned = processMemoryTags(raw);
      const showForm = cleaned.includes('[SHOW_FORM]');
      cleaned = cleaned.replace('[SHOW_FORM]', '').trim();

      if (showForm) {
        if (cleaned.length > 5) addMsg('ai', fmt(cleaned), agentId);
        showResForm(agentId);
      } else {
        addMsg('ai', fmt(cleaned), agentId, getQRs(agentId));
      }

      History.add('assistant', cleaned);
      setPill(`${agent.emoji} ${agent.name} odpověděl`, agent.color, false);
      setTimeout(() => setPill('Čekám na váš dotaz…', '#9E8E7A', false), 3000);

    } catch (err) {
      hideTyping();
      addMsg('ai', 'Omlouvám se, nastala chyba. Zavolejte: <b>+420 222 333 444</b>', 'support');
      setPill('Chyba', '#E05757', false);
      console.error('[BV Widget]', err);
    }
    busy = false;
  }

  window._bvS = t => { document.getElementById('bv-inp').value = t; process(t); };

  function renderToast() {
    const m = Memory.getAll();
    const keys = Object.keys(m).filter(k => !k.startsWith('_'));
    const el = document.getElementById('bv-toast-content');
    el.innerHTML = keys.length
      ? keys.map(k => `<b>${k}</b>: ${Array.isArray(m[k]) ? m[k].join(', ') : m[k]}`).join('<br>')
      : 'Žádná uložená data.';
    const t = document.getElementById('bv-toast');
    t.style.display = t.style.display === 'block' ? 'none' : 'block';
  }

  // ─── INIT ────────────────────────────────────────────────
  function init() {
    injectStyles();
    buildDOM();

    document.getElementById('bv-fab').addEventListener('click', toggle);
    document.getElementById('bv-close').addEventListener('click', toggle);
    document.getElementById('bv-membtn').addEventListener('click', renderToast);
    document.getElementById('bv-clearmem').addEventListener('click', () => {
      localStorage.removeItem(STORE_KEY);
      localStorage.removeItem(HIST_KEY);
      document.getElementById('bv-toast').style.display = 'none';
    });
    document.getElementById('bv-send').addEventListener('click', () => {
      const v = document.getElementById('bv-inp').value.trim();
      if (v) { document.getElementById('bv-inp').value = ''; process(v); }
    });
    document.getElementById('bv-inp').addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        const v = e.target.value.trim();
        if (v) { e.target.value = ''; process(v); }
      }
    });

    // Welcome
    setTimeout(() => {
      const fab = document.getElementById('bv-fab');
      const n = document.createElement('div');
      n.className = 'bv-notif'; n.textContent = '1';
      fab.appendChild(n);

      const savedName = Memory.get('name');
      if (savedName) {
        toggle();
        addMsg('ai', `Vítejte zpět, <b>${savedName}</b>! 👋 Čím mohu dnes pomoci?`, 'orchestrator',
          ['Zarezervovat stůl', 'Prohlédnout menu', 'Mám dotaz']);
      }
    }, 2500);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
