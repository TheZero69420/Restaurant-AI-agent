/**
 * ╔══════════════════════════════════════════════════════╗
 * ║  Bella Vita — Secure Claude API Proxy               ║
 * ║  Cloudflare Worker                                  ║
 * ║                                                     ║
 * ║  Nasazení: https://workers.cloudflare.com           ║
 * ║  API klíč ulož jako Secret: ANTHROPIC_API_KEY       ║
 * ╚══════════════════════════════════════════════════════╝
 */

export default {
  async fetch(request, env) {

    // ── CORS preflight ──────────────────────────────────
    if (request.method === 'OPTIONS') {
      return corsResponse('', 204);
    }

    // ── Pouze POST /chat ────────────────────────────────
    const url = new URL(request.url);
    if (request.method !== 'POST' || url.pathname !== '/chat') {
      return corsResponse(JSON.stringify({ error: 'Not found' }), 404);
    }

    // ── Rate limiting (jednoduchý — IP based) ───────────
    const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
    const rateLimitKey = `rate:${ip}`;
    const count = parseInt(await env.KV?.get(rateLimitKey) || '0');

    if (count > 60) { // max 60 requestů za hodinu na IP
      return corsResponse(JSON.stringify({
        error: 'Příliš mnoho požadavků. Zkuste to za chvíli.'
      }), 429);
    }

    // ── Parsuj tělo požadavku ───────────────────────────
    let body;
    try {
      body = await request.json();
    } catch {
      return corsResponse(JSON.stringify({ error: 'Neplatný JSON' }), 400);
    }

    // ── Validace (bezpečnost) ───────────────────────────
    if (!body.messages || !Array.isArray(body.messages)) {
      return corsResponse(JSON.stringify({ error: 'Chybí messages' }), 400);
    }

    // Omez délku zpráv aby zákazník nemohl posílat obří requesty
    const sanitizedMessages = body.messages
      .slice(-20) // max 20 zpráv v historii
      .map(m => ({
        role: m.role === 'user' ? 'user' : 'assistant',
        content: String(m.content || '').slice(0, 2000) // max 2000 znaků na zprávu
      }));

    // ── Volej Claude API s tvým klíčem ─────────────────
    let claudeResponse;
    try {
      claudeResponse = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_API_KEY,          // 🔐 klíč je zde, bezpečně
          'anthropic-version': '2023-06-01',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          system: body.system || '',
          messages: sanitizedMessages,
        }),
      });
    } catch (err) {
      return corsResponse(JSON.stringify({ error: 'Chyba připojení k AI' }), 502);
    }

    if (!claudeResponse.ok) {
      const errText = await claudeResponse.text();
      console.error('Claude API error:', claudeResponse.status, errText);
      return corsResponse(JSON.stringify({ error: 'Chyba AI služby' }), 502);
    }

    const data = await claudeResponse.json();

    // ── Rate limit counter update ───────────────────────
    if (env.KV) {
      await env.KV.put(rateLimitKey, String(count + 1), { expirationTtl: 3600 });
    }

    // ── Vrať odpověď widgetu ────────────────────────────
    return corsResponse(JSON.stringify({
      content: data.content,
      usage: data.usage, // pro monitoring nákladů
    }), 200);
  }
};

// ── Helper: CORS headers ────────────────────────────────
function corsResponse(body, status) {
  return new Response(body, {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',       // nebo konkrétní doména restaurace
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
